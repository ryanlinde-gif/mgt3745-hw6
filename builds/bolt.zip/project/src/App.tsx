import SkillMatch from '@/components/SkillMatch';

function App() {
  return <SkillMatch />;
}

export default App;
