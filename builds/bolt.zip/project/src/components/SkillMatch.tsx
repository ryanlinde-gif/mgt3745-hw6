import { useCallback, useEffect, useMemo, useState } from 'react';
import { Check, Minus, AlertTriangle, Target } from 'lucide-react';
import { supabase, type Role, type RoleSkill, type StudentSkill } from '@/lib/supabase';

const MAX_TOP_SKILLS = 10;

type TopSkill = RoleSkill & { held: boolean };

export default function SkillMatch() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<string>('');
  const [roleSkills, setRoleSkills] = useState<RoleSkill[]>([]);
  const [studentSkills, setStudentSkills] = useState<StudentSkill[]>([]);
  const [studentSkillSet, setStudentSkillSet] = useState<Set<string>>(new Set());
  const [newSkill, setNewSkill] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Initial load: roles + student skills
  useEffect(() => {
    (async () => {
      try {
        const [rolesRes, skillsRes] = await Promise.all([
          supabase.from('roles').select('id, title, description').order('title'),
          supabase.from('student_skills').select('id, name').order('name'),
        ]);
        if (rolesRes.error) throw rolesRes.error;
        if (skillsRes.error) throw skillsRes.error;
        setRoles(rolesRes.data ?? []);
        setStudentSkills(skillsRes.data ?? []);
        setStudentSkillSet(new Set((skillsRes.data ?? []).map((s) => s.name)));
        if (rolesRes.data && rolesRes.data.length > 0) {
          setSelectedRoleId(rolesRes.data[0].id);
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Could not load data.');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Load ranked skills whenever the selected role changes
  useEffect(() => {
    if (!selectedRoleId) {
      setRoleSkills([]);
      return;
    }
    (async () => {
      try {
        const { data, error: err } = await supabase
          .from('role_skills')
          .select('id, role_id, name, rank')
          .eq('role_id', selectedRoleId)
          .order('rank', { ascending: true });
        if (err) throw err;
        setRoleSkills(data ?? []);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Could not load role skills.');
      }
    })();
  }, [selectedRoleId]);

  const topSkills: TopSkill[] = useMemo(() => {
    const ranked = [...roleSkills].sort((a, b) => a.rank - b.rank);
    const used = ranked.slice(0, MAX_TOP_SKILLS);
    return used.map((s) => ({ ...s, held: studentSkillSet.has(s.name) }));
  }, [roleSkills, studentSkillSet]);

  const totalUsed = topSkills.length;
  const heldCount = topSkills.filter((s) => s.held).length;
  const gapCount = totalUsed - heldCount;
  const belowHalf = totalUsed > 0 && heldCount < totalUsed / 2;
  const sharePct = totalUsed > 0 ? Math.round((heldCount / totalUsed) * 100) : 0;

  const addSkill = useCallback(async () => {
    const name = newSkill.trim();
    if (!name || studentSkillSet.has(name)) {
      setNewSkill('');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const { data, error: err } = await supabase
        .from('student_skills')
        .insert({ name })
        .select('id, name')
        .maybeSingle();
      if (err) {
        if (err.code === '23505') {
          setStudentSkillSet((prev) => new Set(prev).add(name));
        } else {
          throw err;
        }
      } else if (data) {
        setStudentSkills((prev) =>
          [...prev, data].sort((a, b) => a.name.localeCompare(b.name)),
        );
        setStudentSkillSet((prev) => new Set(prev).add(data.name));
      }
      setNewSkill('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not add skill.');
    } finally {
      setBusy(false);
    }
  }, [newSkill, studentSkillSet]);

  const removeSkill = useCallback(async (name: string) => {
    setBusy(true);
    setError(null);
    try {
      const { error: err } = await supabase
        .from('student_skills')
        .delete()
        .eq('name', name);
      if (err) throw err;
      setStudentSkills((prev) => prev.filter((s) => s.name !== name));
      setStudentSkillSet((prev) => {
        const next = new Set(prev);
        next.delete(name);
        return next;
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not remove skill.');
    } finally {
      setBusy(false);
    }
  }, []);

  if (loading) {
    return (
      <div style={{ color: 'var(--color-text-muted)' }} className="text-center py-16">
        Loading…
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-10 animate-fade-in">
      <header className="mb-8">
        <h1
          className="font-semibold tracking-tight"
          style={{ fontSize: '1.75rem', color: 'var(--color-text)', lineHeight: 1.2 }}
        >
          Share of Top Skills Held
        </h1>
        <p style={{ color: 'var(--color-text-muted)' }} className="mt-1">
          See how many of the most important skills for a role you already have.
          The decision to apply is always yours.
        </p>
      </header>

      {error && (
        <div
          role="alert"
          className="mb-6 px-4 py-3 rounded flex items-start gap-2"
          style={{
            color: 'var(--color-danger)',
            background: 'var(--color-surface)',
            border: '1px solid var(--color-danger)',
          }}
        >
          <AlertTriangle size={18} style={{ flexShrink: 0, marginTop: 2 }} />
          <span>{error}</span>
        </div>
      )}

      <RoleSelector
        roles={roles}
        selectedId={selectedRoleId}
        onSelect={setSelectedRoleId}
      />

      {selectedRoleDescription(roles, selectedRoleId)}

      <ResultPanel
        heldCount={heldCount}
        totalUsed={totalUsed}
        gapCount={gapCount}
        sharePct={sharePct}
        belowHalf={belowHalf}
      />

      <SkillList topSkills={topSkills} totalUsed={totalUsed} />

      <StudentSkillManager
        skills={studentSkills}
        newSkill={newSkill}
        busy={busy}
        onNewSkillChange={setNewSkill}
        onAdd={addSkill}
        onRemove={removeSkill}
      />
    </div>
  );
}

function selectedRoleDescription(roles: Role[], id: string) {
  const role = roles.find((r) => r.id === id);
  if (!role?.description) return null;
  return (
    <p style={{ color: 'var(--color-text-muted)' }} className="mt-2 mb-6">
      {role.description}
    </p>
  );
}

type RoleSelectorProps = {
  roles: Role[];
  selectedId: string;
  onSelect: (id: string) => void;
};

function RoleSelector({ roles, selectedId, onSelect }: RoleSelectorProps) {
  return (
    <div className="mb-6">
      <label
        htmlFor="role-select"
        className="block mb-2"
        style={{ fontWeight: 600, color: 'var(--color-text)' }}
      >
        Target role
      </label>
      <select
        id="role-select"
        value={selectedId}
        onChange={(e) => onSelect(e.target.value)}
        className="w-full px-3 py-2"
        style={{
          background: 'var(--color-surface)',
          color: 'var(--color-text)',
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius)',
        }}
      >
        {roles.map((r) => (
          <option key={r.id} value={r.id}>
            {r.title}
          </option>
        ))}
      </select>
    </div>
  );
}

type ResultPanelProps = {
  heldCount: number;
  totalUsed: number;
  gapCount: number;
  sharePct: number;
  belowHalf: boolean;
};

function ResultPanel({
  heldCount,
  totalUsed,
  gapCount,
  sharePct,
  belowHalf,
}: ResultPanelProps) {
  if (totalUsed === 0) {
    return (
      <div
        className="p-6 mb-8"
        style={{
          background: 'var(--color-surface)',
          border: '1px solid var(--color-divider)',
          borderRadius: 'var(--radius)',
        }}
      >
        <p style={{ color: 'var(--color-text-muted)' }}>
          This role does not have ranked skills yet.
        </p>
      </div>
    );
  }

  return (
    <section
      aria-live="polite"
      className="mb-8 p-6 sm:p-8"
      style={{
        background: 'var(--color-surface)',
        border: '1px solid var(--color-divider)',
        borderRadius: 'var(--radius)',
      }}
    >
      <div className="flex items-center gap-2 mb-4">
        <Target size={20} style={{ color: 'var(--color-primary)' }} />
        <span
          className="uppercase"
          style={{
            color: 'var(--color-text-muted)',
            fontWeight: 600,
            letterSpacing: '0.04em',
            fontSize: '0.75rem',
          }}
        >
          Your result
        </span>
      </div>

      <div className="flex items-baseline gap-2 flex-wrap">
        <span
          style={{
            fontSize: '3.5rem',
            fontWeight: 700,
            color: 'var(--color-primary)',
            lineHeight: 1,
          }}
        >
          {heldCount}
        </span>
        <span
          style={{
            fontSize: '1.75rem',
            color: 'var(--color-text-muted)',
            lineHeight: 1,
          }}
        >
          of {totalUsed}
        </span>
        <span style={{ color: 'var(--color-text)' }} className="ml-1">
          top skills held
        </span>
      </div>

      <p style={{ color: 'var(--color-text)' }} className="mt-3">
        You already have {heldCount} of the {totalUsed} most important skills
        for this role. {gapCount > 0 ? `${gapCount} remain to grow into.` : 'You have every top skill listed.'}
      </p>

      <ProgressBar pct={sharePct} held={heldCount} total={totalUsed} />

      {belowHalf ? (
        <div
          className="mt-5 p-4 flex items-start gap-2"
          style={{
            background: 'var(--color-attention-surface)',
            border: '1px solid var(--color-attention)',
            borderRadius: 'var(--radius)',
            color: 'var(--color-attention)',
          }}
        >
          <AlertTriangle size={18} style={{ flexShrink: 0, marginTop: 2 }} />
          <div>
            <p style={{ fontWeight: 600, color: 'var(--color-attention)' }}>
              You have fewer than half of the top skills.
            </p>
            <p
              style={{
                color: 'var(--color-attention)',
                marginTop: '0.25rem',
              }}
            >
              The gap is shown above. Whether to apply is your call — job
              descriptions describe the employer&apos;s preferred candidate,
              not a strict checklist.
            </p>
          </div>
        </div>
      ) : (
        <p style={{ color: 'var(--color-text-muted)' }} className="mt-5">
          You have at least half of the top skills. Whether to apply is your
          call — job descriptions describe the employer&apos;s preferred
          candidate, not a strict checklist.
        </p>
      )}
    </section>
  );
}

function ProgressBar({ pct, held, total }: { pct: number; held: number; total: number }) {
  return (
    <div className="mt-4">
      <div
        className="w-full h-3 overflow-hidden"
        style={{
          background: 'var(--color-divider)',
          borderRadius: 'var(--radius)',
        }}
        role="progressbar"
        aria-valuenow={held}
        aria-valuemin={0}
        aria-valuemax={total}
        aria-label={`You hold ${held} of ${total} top skills`}
      >
        <div
          className="h-full animate-bar-grow"
          style={{
            width: `${pct}%`,
            background: 'var(--color-primary)',
            borderRadius: 'var(--radius)',
          }}
        />
      </div>
      <div
        className="flex justify-between mt-1"
        style={{ color: 'var(--color-text-muted)', fontSize: '0.75rem' }}
      >
        <span>{held} held</span>
        <span>{Math.max(0, total - held)} gap</span>
      </div>
    </div>
  );
}

type SkillListProps = {
  topSkills: TopSkill[];
  totalUsed: number;
};

function SkillList({ topSkills, totalUsed }: SkillListProps) {
  if (totalUsed === 0) return null;
  return (
    <section className="mb-8">
      <h2
        className="mb-3"
        style={{ fontWeight: 600, color: 'var(--color-text)', fontSize: '1.1rem' }}
      >
        Top {totalUsed} skills for this role
      </h2>
      <ul className="space-y-1" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
        {topSkills.map((s) => (
          <li
            key={s.id}
            className="flex items-center gap-3 px-3 py-2"
            style={{
              background: 'var(--color-surface)',
              border: '1px solid var(--color-divider)',
              borderRadius: 'var(--radius)',
            }}
          >
            <span
              className="inline-flex items-center justify-center"
              style={{
                width: 22,
                height: 22,
                borderRadius: '50%',
                background: s.held ? 'var(--color-primary)' : 'var(--color-surface)',
                border: s.held
                  ? '1px solid var(--color-primary)'
                  : '1px solid var(--color-border)',
                flexShrink: 0,
              }}
            >
              {s.held ? (
                <Check size={14} style={{ color: 'var(--color-on-primary)' }} />
              ) : (
                <Minus size={14} style={{ color: 'var(--color-text-muted)' }} />
              )}
            </span>
            <span style={{ color: 'var(--color-text)' }}>{s.name}</span>
            <span
              className="ml-auto"
              style={{ color: 'var(--color-text-muted)', fontSize: '0.75rem' }}
            >
              #{s.rank}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

type StudentSkillManagerProps = {
  skills: StudentSkill[];
  newSkill: string;
  busy: boolean;
  onNewSkillChange: (v: string) => void;
  onAdd: () => void;
  onRemove: (name: string) => void;
};

function StudentSkillManager({
  skills,
  newSkill,
  busy,
  onNewSkillChange,
  onAdd,
  onRemove,
}: StudentSkillManagerProps) {
  return (
    <section>
      <h2
        className="mb-3"
        style={{ fontWeight: 600, color: 'var(--color-text)', fontSize: '1.1rem' }}
      >
        Skills you have
      </h2>
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={newSkill}
          onChange={(e) => onNewSkillChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') onAdd();
          }}
          placeholder="Add a skill you have"
          disabled={busy}
          className="flex-1 px-3 py-2"
          style={{
            background: 'var(--color-surface)',
            color: 'var(--color-text)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius)',
          }}
        />
        <button
          type="button"
          onClick={onAdd}
          disabled={busy || !newSkill.trim()}
          className="px-4 py-2 transition-colors"
          style={{
            background: 'var(--color-primary)',
            color: 'var(--color-on-primary)',
            border: '1px solid var(--color-primary)',
            borderRadius: 'var(--radius)',
            fontWeight: 600,
            opacity: busy || !newSkill.trim() ? 0.6 : 1,
            cursor: busy || !newSkill.trim() ? 'not-allowed' : 'pointer',
          }}
        >
          Add
        </button>
      </div>
      {skills.length === 0 ? (
        <p style={{ color: 'var(--color-text-muted)' }}>
          No skills added yet. Add the skills you have to see your match.
        </p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {skills.map((s) => (
            <span
              key={s.id}
              className="inline-flex items-center gap-1.5 px-3 py-1.5"
              style={{
                background: 'var(--color-surface)',
                color: 'var(--color-text)',
                border: '1px solid var(--color-divider)',
                borderRadius: 'var(--radius)',
              }}
            >
              {s.name}
              <button
                type="button"
                onClick={() => onRemove(s.name)}
                disabled={busy}
                aria-label={`Remove ${s.name}`}
                className="inline-flex items-center justify-center transition-colors"
                style={{
                  color: 'var(--color-text-muted)',
                  background: 'transparent',
                  border: 'none',
                  cursor: busy ? 'not-allowed' : 'pointer',
                  padding: 0,
                  lineHeight: 1,
                }}
              >
                <Minus size={14} />
              </button>
            </span>
          ))}
        </div>
      )}
    </section>
  );
}
