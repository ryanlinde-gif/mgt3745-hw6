import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Role = {
  id: string;
  title: string;
  description: string;
};

export type RoleSkill = {
  id: string;
  role_id: string;
  name: string;
  rank: number;
};

export type StudentSkill = {
  id: string;
  name: string;
};
