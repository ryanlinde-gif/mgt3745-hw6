/*
# Skill match tables (single-tenant, no auth)

1. New Tables
- `roles` — a target tech role (e.g. Junior Frontend Developer).
  - id (uuid, pk), title (text), description (text)
- `role_skills` — ranked skills for a role. rank 1 = most important.
  - id (uuid, pk), role_id (uuid fk -> roles), name (text), rank (int)
- `student_skills` — skills the student (Devon) already has.
  - id (uuid, pk), name (text)
2. Security
- Single-tenant, no sign-in. RLS enabled on all tables with anon+authenticated
  CRUD so the anon-key frontend can read and write its own shared data.
3. Notes
- Seed data included: one role with 10 ranked skills, one role with 6 ranked
  skills (to exercise the <10 case), and a starter set of student skills.
*/

CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT ''
);

ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_roles" ON roles;
CREATE POLICY "anon_select_roles" ON roles FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_roles" ON roles;
CREATE POLICY "anon_insert_roles" ON roles FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_roles" ON roles;
CREATE POLICY "anon_update_roles" ON roles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_roles" ON roles;
CREATE POLICY "anon_delete_roles" ON roles FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS role_skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  name text NOT NULL,
  rank int NOT NULL,
  UNIQUE (role_id, rank),
  UNIQUE (role_id, name)
);

ALTER TABLE role_skills ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_role_skills" ON role_skills;
CREATE POLICY "anon_select_role_skills" ON role_skills FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_role_skills" ON role_skills;
CREATE POLICY "anon_insert_role_skills" ON role_skills FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_role_skills" ON role_skills;
CREATE POLICY "anon_update_role_skills" ON role_skills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_role_skills" ON role_skills;
CREATE POLICY "anon_delete_role_skills" ON role_skills FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS student_skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE
);

ALTER TABLE student_skills ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_student_skills" ON student_skills;
CREATE POLICY "anon_select_student_skills" ON student_skills FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_student_skills" ON student_skills;
CREATE POLICY "anon_insert_student_skills" ON student_skills FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_student_skills" ON student_skills;
CREATE POLICY "anon_update_student_skills" ON student_skills FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_student_skills" ON student_skills;
CREATE POLICY "anon_delete_student_skills" ON student_skills FOR DELETE TO anon, authenticated USING (true);

-- Seed: roles
INSERT INTO roles (id, title, description) VALUES
  ('11111111-1111-1111-1111-111111111111', 'Junior Frontend Developer', 'Entry-level role building user interfaces with modern web tooling.'),
  ('22222222-2222-2222-2222-222222222222', 'IT Support Specialist', 'First-line technical support role with a narrower required skill set.')
ON CONFLICT (id) DO NOTHING;

-- Seed: ranked skills for Junior Frontend Developer (10 skills)
INSERT INTO role_skills (role_id, name, rank) VALUES
  ('11111111-1111-1111-1111-111111111111', 'HTML', 1),
  ('11111111-1111-1111-1111-111111111111', 'CSS', 2),
  ('11111111-1111-1111-1111-111111111111', 'JavaScript', 3),
  ('11111111-1111-1111-1111-111111111111', 'Git', 4),
  ('11111111-1111-1111-1111-111111111111', 'React', 5),
  ('11111111-1111-1111-1111-111111111111', 'Responsive Design', 6),
  ('11111111-1111-1111-1111-111111111111', 'TypeScript', 7),
  ('11111111-1111-1111-1111-111111111111', 'Testing', 8),
  ('11111111-1111-1111-1111-111111111111', 'Accessibility', 9),
  ('11111111-1111-1111-1111-111111111111', 'Performance', 10)
ON CONFLICT DO NOTHING;

-- Seed: ranked skills for IT Support Specialist (6 skills — exercises the <10 case)
INSERT INTO role_skills (role_id, name, rank) VALUES
  ('22222222-2222-2222-2222-222222222222', 'Windows', 1),
  ('22222222-2222-2222-2222-222222222222', 'Networking', 2),
  ('22222222-2222-2222-2222-222222222222', 'Active Directory', 3),
  ('22222222-2222-2222-2222-222222222222', 'Troubleshooting', 4),
  ('22222222-2222-2222-2222-222222222222', 'Customer Service', 5),
  ('22222222-2222-2222-2222-222222222222', 'Office 365', 6)
ON CONFLICT DO NOTHING;

-- Seed: student skills (Devon has 4 of the top frontend skills — below half, exercises F3-2)
INSERT INTO student_skills (name) VALUES
  ('HTML'),
  ('CSS'),
  ('JavaScript'),
  ('Git'),
  ('Python'),
  ('SQL'),
  ('Customer Service')
ON CONFLICT DO NOTHING;
